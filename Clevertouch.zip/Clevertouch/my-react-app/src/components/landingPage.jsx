import React from 'react';
import ' ./landingPage.css'
import { assets } from '../../assets/assets';

